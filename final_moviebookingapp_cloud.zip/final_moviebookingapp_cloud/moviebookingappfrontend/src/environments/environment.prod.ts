export const environment = {
  production: true,
  baseUrl:"http://backend.h0hyb3djhsakeagm.northeurope.azurecontainer.io:8081/api/v1.0/moviebooking"
};
