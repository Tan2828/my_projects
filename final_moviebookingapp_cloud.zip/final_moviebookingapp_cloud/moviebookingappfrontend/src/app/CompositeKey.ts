export class CompositeKey{
    movieName:string=''
    theatreName:string=''
}