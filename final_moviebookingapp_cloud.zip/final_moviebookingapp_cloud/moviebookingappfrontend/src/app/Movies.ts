import { CompositeKey } from "./CompositeKey";

export class Movies{
    key!:CompositeKey
    totalNoOfTickets!:number
}