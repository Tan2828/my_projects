package com.moviebookingapp.exception;

public class PasswordMismatchException extends Exception{
	
	public PasswordMismatchException(String msg) {
		super(msg);
	}

}
