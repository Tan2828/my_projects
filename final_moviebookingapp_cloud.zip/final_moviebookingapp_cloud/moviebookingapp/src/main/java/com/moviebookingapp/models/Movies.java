package com.moviebookingapp.models;

import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Document(collection="movies")
public class Movies {
	
	@Id
	@Indexed
	private CompositeKey key;
	
	@NotNull(message="Please enter total number of tickets available")
	private int totalNoOfTickets;

	
    

}
//package com.moviebookingapp.models;
//
//import java.io.Serializable;
//
//import javax.validation.constraints.NotNull;
//
//import org.springframework.data.annotation.PersistenceConstructor;
//import org.springframework.data.mongodb.core.mapping.Document;
//import org.springframework.data.mongodb.core.mapping.Field;
//import org.springframework.data.mongodb.core.mapping.FieldType;
//import org.springframework.data.mongodb.core.mapping.MongoId;
//
//@SuppressWarnings("deprecation")
//@Document(collection = "movies")
//public class Movies implements Serializable {
//
//    @MongoId(targetType = FieldType.OBJECT_ID)
//    @Field("_id")
//    private String id;
//
//    @NotNull(message = "Please enter the total number of tickets available")
//    private int totalNoOfTickets;
//
//    @PersistenceConstructor
//    public Movies(String id, int totalNoOfTickets) {
//        this.id = id;
//        this.totalNoOfTickets = totalNoOfTickets;
//    }
//
//    // Getters and setters
//
//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }
//
//    public int getTotalNoOfTickets() {
//        return totalNoOfTickets;
//    }
//
//    public void setTotalNoOfTickets(int totalNoOfTickets) {
//        this.totalNoOfTickets = totalNoOfTickets;
//    }
//
//    // Equals and hashCode methods
//
//    // Rest of the code
//}
