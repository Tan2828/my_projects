package com.moviebookingapp.exception;

public class NoTicketBookedException extends Exception{
	public NoTicketBookedException(String msg) {
		super(msg);
	}

}
